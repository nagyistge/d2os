package mapred;

import dpm.MasterProcess;

public class MRMaster extends MasterProcess {

	@Override
	public void start(){
		
	}
}
