package cloudos.kernel;

public enum SystemCallErrorType {
	NONE, FATAL, WARNING
}
