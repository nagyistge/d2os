package watershed.core;

public abstract class ChannelDecoder<InputType, OutputType> extends ChannelDeliver<OutputType> implements ChannelReceiver<InputType> {
}
