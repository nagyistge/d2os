package dpm;

import cloudos.kernel.DefaultExecutor;

public abstract class BasicProcess extends DefaultExecutor {
}

