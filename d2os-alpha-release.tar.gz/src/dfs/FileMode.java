package dfs;

public enum FileMode {
	READER, WRITER, APPENDER
}

