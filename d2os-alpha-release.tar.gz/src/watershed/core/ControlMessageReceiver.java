package watershed.core;

public interface ControlMessageReceiver {
	public void receiveCtrlMsg(ControlMessage ctrlMsg);
}
