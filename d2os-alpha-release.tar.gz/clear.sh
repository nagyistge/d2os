cd $CLOUDOS_HOME

find . -name "*~" -delete
