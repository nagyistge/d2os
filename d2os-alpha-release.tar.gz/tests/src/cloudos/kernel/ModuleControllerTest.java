package cloudos.kernel;

import org.junit.* ;
import static org.junit.Assert.* ;

public class ModuleControllerTest {
	@Test
	public void testNodeExecutor() throws Exception{
		NodeExecutor.setup(null, null);
	}
}
